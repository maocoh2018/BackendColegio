﻿using System;
using System.Collections.Generic;
using System.Text;
using APIEjemplo.Context;

namespace ApiEjemplo.Datos.Base
{
    public class UnitOfWork 
    {
        
       
        private SolicitudesRepository solicitudesRepository;

        public SolicitudesRepository SolicitudesRepository
        {
            get
            {
                if (this.solicitudesRepository == null)
                    this.solicitudesRepository = new SolicitudesRepository();
                return solicitudesRepository;
            }
        }       
    }
}
