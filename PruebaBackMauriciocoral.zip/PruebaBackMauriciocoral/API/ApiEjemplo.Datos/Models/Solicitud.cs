﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace ApiEjemplo.Datos.Models
{
    public class Solicitud
    {
        [Key]
        public int Id_Solicitud { get; set; }
        public string Nombre { get; set; }
        public string Apellido { get; set; }
        public int Identificacion { get; set; }
        public int Edad { get; set; }
        public int Id_Casa { get; set; }
    }
}
