﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Data.SqlClient;

namespace ApiEjemplo.Datos
{
    internal class ConnectionDAL
    {
        private static SqlConnection conexion;
        private static ConnectionDAL singleton;

        public SqlConnection ConnetionFactory
        {
            get { return conexion; }
        }

        private ConnectionDAL()
        {
        }

        public static string Cadena()
        {
            try
            {
                string CadenaConexion = "Data Source=.;Initial Catalog=Colegio;Integrated Security=True;MultipleActiveResultSets=true";
                return CadenaConexion;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public static ConnectionDAL Singleton
        {
            get
            {
                if (singleton == null)
                    singleton = new ConnectionDAL();
                conexion = new SqlConnection(Cadena());
                //conexion.Open();
                return singleton;
            }
        }

    }
}
