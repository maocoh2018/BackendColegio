﻿using System;
using System.Collections.Generic;
using System.Text;
using APIEjemplo.Context;

namespace ApiEjemplo.Datos
{
    public class UOWRepository
    {
        private readonly static SolicitudesRepository _SolicitudesRepository = new SolicitudesRepository();
        private readonly AppDbContext context;
        


        private UOWRepository() { }
        public static SolicitudesRepository PreempaqueRepository
        {
            get
            {
                return _SolicitudesRepository;
            }
        }
    }
}
