﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using ApiEjemplo.Datos.Models;
using APIEjemplo.Context;
using Microsoft.Data.SqlClient;

namespace ApiEjemplo.Datos
{
    public class SolicitudesRepository
    {
       

        SqlConnection Conn = new SqlConnection();
        /// <summary>
        /// Metodo par listar los clientes existentes
        /// </summary>
        /// <returns></returns>
        public List<SolicitudDto> obtenerSolicitudes()
        {

            try
            {
                Conn = ConnectionDAL.Singleton.ConnetionFactory;
                Conn.Open();
                SqlCommand cmd = new SqlCommand("[dbo].[ObtenerSolicitudes]", Conn);
                cmd.CommandType = CommandType.StoredProcedure;

                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(cmd);

                da.Fill(dt);
                List<SolicitudDto> listaClientes = new List<SolicitudDto>();
                listaClientes = (from DataRow dr in dt.Rows
                                 select new SolicitudDto
                                 {
                                     Id_Solicitud = Convert.ToInt32(dr["Id_Solicitud"]),
                                     Nombre = dr["Nombre"].ToString(),
                                     Apellido = dr["Apellido"].ToString(),
                                     Identificacion = Convert.ToInt32(dr["Identificacion"]),
                                     Edad = Convert.ToInt32(dr["Edad"]),
                                     descripcionCasa = dr["Descripcion"].ToString()
                                     
                                 }).ToList();

                return listaClientes;
            }
            catch (Exception ex)
            {
                throw new Exception(" Error al ejecutar procedimiento almacenado ", ex);
            }
            finally
            {
                Conn.Close();
            }
        }


        public List<Solicitud> crearSolicitud(Solicitud solicitud)
        {
            string nombre = solicitud.Nombre;
            string apellido = solicitud.Apellido;
            int identificacion = solicitud.Identificacion;
            int edad = solicitud.Edad;
            int casa = solicitud.Id_Casa;

            try
            {
                Conn = ConnectionDAL.Singleton.ConnetionFactory;
                Conn.Open();
                SqlCommand cmd = new SqlCommand("[dbo].[CrearSolicitud]", Conn);
                cmd.Parameters.Add("@nombre", SqlDbType.VarChar);
                cmd.Parameters["@nombre"].Value = nombre;

                cmd.Parameters.Add("@apellido", SqlDbType.VarChar);
                cmd.Parameters["@apellido"].Value = apellido;

                cmd.Parameters.Add("@identificacion", SqlDbType.Int);
                cmd.Parameters["@identificacion"].Value = identificacion;

                cmd.Parameters.Add("@edad", SqlDbType.Int, edad);
                cmd.Parameters["@edad"].Value = edad;

                cmd.Parameters.Add("@idcasa", SqlDbType.Int, casa);
                cmd.Parameters["@idcasa"].Value = casa;

                cmd.CommandType = CommandType.StoredProcedure;

                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(cmd);

                da.Fill(dt);
                List<Solicitud> listaClientes = new List<Solicitud>();
                listaClientes = (from DataRow dr in dt.Rows
                                 select new Solicitud
                                 {
                                     Id_Solicitud = Convert.ToInt32(dr["Id_Solicitud"]),
                                     Nombre = dr["Nombre"].ToString(),
                                     Apellido = dr["Apellido"].ToString(),
                                     Identificacion = Convert.ToInt32(dr["Identificacion"]),
                                     Edad = Convert.ToInt32(dr["Edad"]),
                                     Id_Casa = Convert.ToInt32(dr["Id_Casa"])

                                 }).ToList();

                return listaClientes;
            }
            catch (Exception ex)
            {
                throw new Exception(" Error al ejecutar procedimiento almacenado ", ex);
            }
            finally
            {
                Conn.Close();
            }
        }

        public List<Solicitud> updateSolicitud(Solicitud solicitud)
        {
            int idsolicitud = solicitud.Id_Solicitud;
            string nombre = solicitud.Nombre;
            string apellido = solicitud.Apellido;
            int identificacion = solicitud.Identificacion;
            int edad = solicitud.Edad;            

            try
            {
                Conn = ConnectionDAL.Singleton.ConnetionFactory;
                Conn.Open();
                SqlCommand cmd = new SqlCommand("[dbo].[UpdateSolicitud]", Conn);

                cmd.Parameters.Add("@IdSolicitud", SqlDbType.Int);
                cmd.Parameters["@IdSolicitud"].Value = idsolicitud;

                cmd.Parameters.Add("@nombre", SqlDbType.VarChar);
                cmd.Parameters["@nombre"].Value = nombre;

                cmd.Parameters.Add("@apellido", SqlDbType.VarChar);
                cmd.Parameters["@apellido"].Value = apellido;

                cmd.Parameters.Add("@identificacion", SqlDbType.Int);
                cmd.Parameters["@identificacion"].Value = identificacion;

                cmd.Parameters.Add("@edad", SqlDbType.Int, edad);
                cmd.Parameters["@edad"].Value = edad;
               
                cmd.CommandType = CommandType.StoredProcedure;

                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(cmd);

                da.Fill(dt);
                List<Solicitud> listaClientes = new List<Solicitud>();
                listaClientes = (from DataRow dr in dt.Rows
                                 select new Solicitud
                                 {
                                     Id_Solicitud = Convert.ToInt32(dr["Id_Solicitud"]),
                                     Nombre = dr["Nombre"].ToString(),
                                     Apellido = dr["Apellido"].ToString(),
                                     Identificacion = Convert.ToInt32(dr["Identificacion"]),
                                     Edad = Convert.ToInt32(dr["Edad"]),
                                     Id_Casa = Convert.ToInt32(dr["Id_Casa"])

                                 }).ToList();

                return listaClientes;
            }
            catch (Exception ex)
            {
                throw new Exception(" Error al ejecutar procedimiento almacenado ", ex);
            }
            finally
            {
                Conn.Close();
            }
        }

        public List<Solicitud> deleteSolicitud(Solicitud solicitud)
        {
            int idsolicitud = solicitud.Id_Solicitud;            

            try
            {
                Conn = ConnectionDAL.Singleton.ConnetionFactory;
                Conn.Open();
                SqlCommand cmd = new SqlCommand("[dbo].[DeleteSolicitud]", Conn);

                cmd.Parameters.Add("@IdSolicitud", SqlDbType.Int);
                cmd.Parameters["@IdSolicitud"].Value = idsolicitud;

                cmd.CommandType = CommandType.StoredProcedure;

                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(cmd);

                da.Fill(dt);
                List<Solicitud> listaClientes = new List<Solicitud>();
                listaClientes = (from DataRow dr in dt.Rows
                                 select new Solicitud
                                 {
                                     Id_Solicitud = Convert.ToInt32(dr["Id_Solicitud"])

                                 }).ToList();

                return listaClientes;
            }
            catch (Exception ex)
            {
                throw new Exception(" Error al ejecutar procedimiento almacenado ", ex);
            }
            finally
            {
                Conn.Close();
            }
        }
    }
}




