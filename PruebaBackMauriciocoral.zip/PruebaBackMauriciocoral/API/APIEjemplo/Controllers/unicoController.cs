﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using ApiEjemplo.Datos.Models;
using ApiEjemplo.Negocio;
using APIEjemplo.Context;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace APIEjemplo.Controllers
{
    
    [Route("api/Ejemplo")]
    [ApiController]
    public class unicoController : ControllerBase
    {

        private readonly AppDbContext context;
        public readonly SolicitudesNegocio _SolicitudesNegocio;


        public unicoController(AppDbContext context)
        {
            this.context = context;
            this._SolicitudesNegocio = new SolicitudesNegocio();
        }


        ///controlador de obtener solicitudes      
        [HttpGet]
        [Route("ObtenerSolicitudes")]
        public ActionResult Get()
        {

            var result = this._SolicitudesNegocio.ObtenerSolicitudes();
            return Ok(JsonConvert.SerializeObject(result));
           
        }

        ///controlador de crear solicitud
        [HttpPost]
        [Route("CrearSolicitud")]
        public ActionResult CrearSolicitud([FromBody] Solicitud solicitud)
        {
            string nombre = solicitud.Nombre;
            string apellido = solicitud.Apellido;
            int identificacion = solicitud.Identificacion;
            int edad = solicitud.Edad;
            int casa = solicitud.Id_Casa;
            
            if (nombre == string.Empty) return BadRequest("Error Request vacio"); 
            if (apellido == string.Empty) return BadRequest("Request vacio");
            if (identificacion == -1) return BadRequest("Request vacio");
            if (edad == -1) return BadRequest("Request vacio");
            if (casa == -1) return BadRequest("Request vacio");


            var result = this._SolicitudesNegocio.CrearSolicitud(solicitud);

            return Ok(JsonConvert.SerializeObject(result));

        }

        ///controlador de actualizar solicitud
        [HttpPost]
        [Route("UpdateSolicitud")]
        public ActionResult UpdateSolicitud([FromBody] Solicitud solicitud)
        {
            int idSolicitud = solicitud.Id_Solicitud;
            string nombre = solicitud.Nombre;
            string apellido = solicitud.Apellido;
            int identificacion = solicitud.Identificacion;
            int edad = solicitud.Edad;            

            if (idSolicitud == -1) return BadRequest("Error Request vacio");
            if (nombre == string.Empty) return BadRequest("Error Request vacio");
            if (apellido == string.Empty) return BadRequest("Request vacio");
            if (identificacion == -1) return BadRequest("Request vacio");
            if (edad == -1) return BadRequest("Request vacio");
            
            var result = this._SolicitudesNegocio.UpdateSolicitud(solicitud);

            return Ok(JsonConvert.SerializeObject(result));

        }

        ///controlador de eliminar solicitud
        [HttpPut]
        [Route("DeleteSolicitud")]
        public ActionResult DeleteSolicitud([FromBody] Solicitud solicitud)
        {

            int idSolicitud = solicitud.Id_Solicitud;          
            if (idSolicitud == -1) return BadRequest("Error Request vacio");            

            var result = this._SolicitudesNegocio.DeleteSolicitud(solicitud);

            return Ok(JsonConvert.SerializeObject(result));

        }



    }
}
