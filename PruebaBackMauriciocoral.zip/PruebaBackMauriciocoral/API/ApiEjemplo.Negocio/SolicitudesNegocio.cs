﻿using System;
using System.Collections.Generic;
using ApiEjemplo.Datos;
using ApiEjemplo.Datos.Base;
using ApiEjemplo.Datos.Models;


namespace ApiEjemplo.Negocio
{
    public class SolicitudesNegocio
    {
        public readonly SolicitudesRepository _SolicitudesNegocio;

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public List<SolicitudDto> ObtenerSolicitudes()
        {
            
                return UOWRepository.PreempaqueRepository.obtenerSolicitudes();
           
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="solicitud"></param>
        /// <returns></returns>
        public List<Solicitud> CrearSolicitud(Solicitud solicitud)
        {
            return UOWRepository.PreempaqueRepository.crearSolicitud(solicitud);

        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="solicitud"></param>
        /// <returns></returns>
        public List<Solicitud> UpdateSolicitud(Solicitud solicitud)
        {
            return UOWRepository.PreempaqueRepository.updateSolicitud(solicitud);

        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="solicitud"></param>
        /// <returns></returns>
        public List<Solicitud> DeleteSolicitud(Solicitud solicitud)
        {
            return UOWRepository.PreempaqueRepository.deleteSolicitud(solicitud);

        }


    }
}
